from django.apps import AppConfig


class LogDetailConfig(AppConfig):
    name = 'log_detail'
